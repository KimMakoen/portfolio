CREATE FUNCTION pg_relation_size (regclass) RETURNS bigint
	LANGUAGE sql
AS $$
select pg_catalog.pg_relation_size($1, 'main')
$$
