CREATE FUNCTION date_part (text, reltime) RETURNS double precision
	LANGUAGE sql
AS $$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$
