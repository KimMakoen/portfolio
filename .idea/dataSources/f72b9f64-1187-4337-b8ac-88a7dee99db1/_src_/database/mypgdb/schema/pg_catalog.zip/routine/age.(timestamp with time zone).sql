CREATE FUNCTION age (timestamp with time zone) RETURNS interval
	LANGUAGE sql
AS $$
select pg_catalog.age(cast(current_date as timestamp with time zone), $1)
$$
